## Інформація
###### Переклад від: Damglador
###### Шрифти: Damglador
###### Все інше: Damglador
###### Озвучення: якщо хочете - пишіть мені :^)
###### Посібник в Steam: https://steamcommunity.com/sharedfiles/filedetails/?id=2903743303
###### GitHub: https://github.com/Damglador/Door-Kickers-Action-Squad-UA
###### Google Drive: https://drive.google.com/file/d/1XPsVjl0Iaackjm_mS_8L2QbJ7F_xPPjs/view?usp=sharing
###### Discord: https://discord.gg/kpwP9d5X4u

## Встановлення
Теку media треба закинути в локальні файли гри (там ще має бути тека media, exe файл гри), має запропонувати замінити всі файли - вибирайте замінити.
Потрапити в локальні файли гри можна натиснувши в Steam правою кнопкою миші по грі - Властивості - Інстальовані файли - Огляд
або натиснувши по ярлику гри і в властивостях має бути шлях до exe файлу, а де exe там і media.

Після заміни файлів - заходите в гру і в Options - More options - Language і там буде українська
